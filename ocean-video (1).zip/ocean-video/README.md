# Ocean video (generic prototype)
1. `npm install`
2. `npm run studio` to preview, `npm run render` to make `out/ocean.mp4` (1080x1920, 42s)

Placeholder land mask is NOT real geography. Colors/fonts are generic.
Timing matches half-the-story-script.md.

## Sound
- `public/ambient.wav` is a generated ambient bed with soft pings at the beat changes (already wired in).
- Voice: record or generate `public/voice.mp3` from `voice-lines.txt` (one take, ~42s, pause at the beat times), then set `HAS_VOICE = true` in `src/Ocean.tsx`.
- Captions of the spoken lines are burned in.
