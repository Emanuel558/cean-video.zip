import React from 'react';
import {AbsoluteFill, Sequence, interpolate, useCurrentFrame, Easing, Audio, staticFile} from 'remotion';
import {Globe} from './Globe';

// Set true after you add public/voice.mp3 (your recording or TTS of the script lines).
const HAS_VOICE = false;

const CAPTIONS: [number, number, string][] = [
  [0, 6, "You think we've seen our planet. But what we've never mapped is bigger than you'd guess."],
  [6, 11, "About seventy percent of Earth is ocean. So let's light up the part we've actually mapped."],
  [11, 18, 'In 2017, only six percent of the ocean floor was mapped.'],
  [18, 27, "Nine years later, it's twenty-eight point seven percent."],
  [27, 33, "That's about a hundred and four million square kilometers. More than two-thirds of all the land on Earth."],
  [33, 38, "So it's not half the story. It's less than a third."],
  [38, 42, 'The goal is all of it by twenty thirty. Right now, most of your planet is still dark.'],
];

export const TOTAL_FRAMES = 1260; // 42s at 30 fps
const f = (s: number) => Math.round(s * 30);

const Text: React.FC<{children: React.ReactNode; size?: number; color?: string}> = ({children, size = 84, color = '#fff'}) => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [0, 8], [0, 1], {extrapolateRight: 'clamp'});
  return (
    <div style={{opacity: o, fontFamily: 'Helvetica, Arial, sans-serif', fontWeight: 800,
      fontSize: size, color, textAlign: 'center', padding: '0 70px', lineHeight: 1.1}}>
      {children}
    </div>
  );
};

export const Ocean: React.FC = () => {
  const frame = useCurrentFrame();

  // Lit fraction of mapped seafloor: 0 -> 6% (2017) -> 28.7% (2026)
  const lit = interpolate(frame, [f(11), f(14), f(18), f(27)], [0, 0.06, 0.06, 0.287],
    {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic)});

  const showCounter = frame >= f(6);
  const year = frame < f(18) ? '2017' : '2026';
  const zoom = interpolate(frame, [f(33), f(38)], [1, 0.8], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const pulse = frame >= f(27) && frame < f(33) ? 1 + 0.03 * Math.sin(frame / 4) : 1;
  const rotation = (frame / TOTAL_FRAMES) * Math.PI * 4;
  // loop: fade to dark in the last 12 frames
  const fade = interpolate(frame, [TOTAL_FRAMES - 12, TOTAL_FRAMES], [1, 0.0], {extrapolateLeft: 'clamp'});

  return (
    <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 50%, #12233f 0%, #070d1a 55%, #03060c 100%)'}}>
      <Audio src={staticFile('ambient.wav')} volume={0.6} />
      {HAS_VOICE && <Audio src={staticFile('voice.mp3')} volume={1} />}
      <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', transform: `scale(${zoom * pulse})`}}>
        <Globe size={1000} rotation={rotation} litFraction={lit} dim={1} />
      </AbsoluteFill>

      {/* top text */}
      <AbsoluteFill style={{justifyContent: 'flex-start', alignItems: 'center', paddingTop: 170}}>
        <Sequence from={0} durationInFrames={f(6)}><Text>WHAT WE'VE NEVER MAPPED</Text></Sequence>
        <Sequence from={f(6)} durationInFrames={f(5)}><Text size={64}>About 70% of Earth is ocean</Text></Sequence>
        <Sequence from={f(11)} durationInFrames={f(7)}><Text size={64}>{year}</Text></Sequence>
        <Sequence from={f(18)} durationInFrames={f(9)}><Text size={64}>{year}</Text></Sequence>
        <Sequence from={f(27)} durationInFrames={f(6)}><Text size={64}>~104 million km²</Text></Sequence>
        <Sequence from={f(33)} durationInFrames={f(5)}><Text color="#3dd6ff">LESS THAN A THIRD</Text></Sequence>
        <Sequence from={f(38)} durationInFrames={f(4)}><Text size={64}>Goal: all of it by 2030</Text></Sequence>
      </AbsoluteFill>

      {/* captions (spoken lines) */}
      {CAPTIONS.map(([a, b, t], i) => (
        <Sequence key={i} from={f(a)} durationInFrames={f(b - a)}>
          <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', paddingBottom: 560}}>
            <div style={{fontFamily: 'Helvetica, Arial, sans-serif', fontWeight: 800, fontSize: 54, color: '#fff',
              textAlign: 'center', padding: '0 80px', lineHeight: 1.2, textShadow: '0 4px 18px #000, 0 0 6px #000'}}>{t}</div>
          </AbsoluteFill>
        </Sequence>
      ))}

      {/* counter */}
      {showCounter && (
        <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', paddingBottom: 320}}>
          <div style={{fontFamily: 'Helvetica, Arial, sans-serif', fontWeight: 900, fontSize: 190, color: '#3dd6ff'}}>
            {(lit * 100).toFixed(1)}%
          </div>
        </AbsoluteFill>
      )}

      {/* source line, last 2s */}
      <Sequence from={f(40)}>
        <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', paddingBottom: 150}}>
          <Text size={36} color="#9aa4b2">Source: Seabed 2030, April 2026</Text>
        </AbsoluteFill>
      </Sequence>

      <AbsoluteFill style={{backgroundColor: '#05080f', opacity: 1 - fade}} />
    </AbsoluteFill>
  );
};
