import {Composition} from 'remotion';
import {Ocean, TOTAL_FRAMES} from './Ocean';

export const Root = () => (
  <Composition id="Ocean" component={Ocean} durationInFrames={TOTAL_FRAMES}
    fps={30} width={1080} height={1920} />
);
