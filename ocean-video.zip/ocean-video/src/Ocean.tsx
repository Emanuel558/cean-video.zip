import React from 'react';
import {AbsoluteFill, Sequence, interpolate, useCurrentFrame, Easing} from 'remotion';
import {Globe} from './Globe';

export const TOTAL_FRAMES = 1260; // 42s at 30 fps
const f = (s: number) => Math.round(s * 30);

const Text: React.FC<{children: React.ReactNode; size?: number; color?: string}> = ({children, size = 84, color = '#fff'}) => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [0, 8], [0, 1], {extrapolateRight: 'clamp'});
  return (
    <div style={{opacity: o, fontFamily: 'Helvetica, Arial, sans-serif', fontWeight: 800,
      fontSize: size, color, textAlign: 'center', padding: '0 70px', lineHeight: 1.1}}>
      {children}
    </div>
  );
};

export const Ocean: React.FC = () => {
  const frame = useCurrentFrame();

  // Lit fraction of mapped seafloor: 0 -> 6% (2017) -> 28.7% (2026)
  const lit = interpolate(frame, [f(11), f(14), f(18), f(27)], [0, 0.06, 0.06, 0.287],
    {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic)});

  const showCounter = frame >= f(6);
  const year = frame < f(18) ? '2017' : '2026';
  const zoom = interpolate(frame, [f(33), f(38)], [1, 0.8], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const pulse = frame >= f(27) && frame < f(33) ? 1 + 0.03 * Math.sin(frame / 4) : 1;
  const rotation = (frame / TOTAL_FRAMES) * Math.PI * 4;
  // loop: fade to dark in the last 12 frames
  const fade = interpolate(frame, [TOTAL_FRAMES - 12, TOTAL_FRAMES], [1, 0.0], {extrapolateLeft: 'clamp'});

  return (
    <AbsoluteFill style={{backgroundColor: '#05080f'}}>
      <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', transform: `scale(${zoom * pulse})`}}>
        <Globe size={1000} rotation={rotation} litFraction={lit} dim={0.7} />
      </AbsoluteFill>

      {/* top text */}
      <AbsoluteFill style={{justifyContent: 'flex-start', alignItems: 'center', paddingTop: 170}}>
        <Sequence from={0} durationInFrames={f(6)}><Text>WHAT WE'VE NEVER MAPPED</Text></Sequence>
        <Sequence from={f(6)} durationInFrames={f(5)}><Text size={64}>About 70% of Earth is ocean</Text></Sequence>
        <Sequence from={f(11)} durationInFrames={f(7)}><Text size={64}>{year}</Text></Sequence>
        <Sequence from={f(18)} durationInFrames={f(9)}><Text size={64}>{year}</Text></Sequence>
        <Sequence from={f(27)} durationInFrames={f(6)}><Text size={64}>~104 million km²</Text></Sequence>
        <Sequence from={f(33)} durationInFrames={f(5)}><Text color="#3dd6ff">LESS THAN A THIRD</Text></Sequence>
        <Sequence from={f(38)} durationInFrames={f(4)}><Text size={64}>Goal: all of it by 2030</Text></Sequence>
      </AbsoluteFill>

      {/* counter */}
      {showCounter && (
        <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', paddingBottom: 320}}>
          <div style={{fontFamily: 'Helvetica, Arial, sans-serif', fontWeight: 900, fontSize: 190, color: '#3dd6ff'}}>
            {(lit * 100).toFixed(1)}%
          </div>
        </AbsoluteFill>
      )}

      {/* source line, last 2s */}
      <Sequence from={f(40)}>
        <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', paddingBottom: 150}}>
          <Text size={36} color="#9aa4b2">Source: Seabed 2030, April 2026</Text>
        </AbsoluteFill>
      </Sequence>

      <AbsoluteFill style={{backgroundColor: '#05080f', opacity: 1 - fade}} />
    </AbsoluteFill>
  );
};
