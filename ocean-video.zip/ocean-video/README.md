# Ocean video (generic prototype)
1. `npm install`
2. `npm run studio` to preview, `npm run render` to make `out/ocean.mp4` (1080x1920, 42s)

Placeholder land mask is NOT real geography. Colors/fonts are generic.
Timing matches half-the-story-script.md.
