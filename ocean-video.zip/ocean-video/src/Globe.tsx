import React from 'react';

// Placeholder globe: Fibonacci dots on a sphere. Land is a pseudo-random mask
// (NOT real geography) so the prototype stays generic. Swap in real land data later.
const N = 2200;
const hash = (i: number) => {
  const x = Math.sin(i * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

type Dot = {lat: number; lon: number; land: boolean; rank: number};
const dots: Dot[] = Array.from({length: N}, (_, i) => {
  const y = 1 - (2 * (i + 0.5)) / N;
  const lat = Math.asin(y);
  const lon = (i * Math.PI * (3 - Math.sqrt(5))) % (2 * Math.PI);
  // clumpy mask: smooth-ish function of position, ~29% land
  const clump = Math.sin(lon * 2.1 + lat * 3) + Math.sin(lon * 3.7 - lat * 2.3) + Math.cos(lat * 5 + lon);
  return {lat, lon, land: clump > 1.35, rank: hash(i)};
});

export const Globe: React.FC<{
  size: number; rotation: number; litFraction: number; dim: number;
}> = ({size, rotation, litFraction, dim}) => {
  const r = size / 2;
  const oceanDots = dots.filter((d) => !d.land);
  return (
    <svg width={size} height={size} viewBox={`${-r} ${-r} ${size} ${size}`}>
      {dots.map((d, i) => {
        const lon = d.lon + rotation;
        const x = Math.cos(d.lat) * Math.sin(lon);
        const z = Math.cos(d.lat) * Math.cos(lon);
        if (z < 0) return null; // back side hidden
        const y = Math.sin(d.lat);
        // ocean rank among ocean dots decides when it lights up
        const lit = !d.land && d.rank < litFraction * (dots.length / oceanDots.length) * 0.9999;
        const fill = d.land ? '#3a3f4a' : lit ? '#3dd6ff' : '#1a2230';
        const opacity = (0.25 + 0.75 * z) * (lit ? 1 : dim);
        return <circle key={i} cx={x * r * 0.95} cy={-y * r * 0.95} r={2 + z * 2.2} fill={fill} opacity={opacity} />;
      })}
    </svg>
  );
};
